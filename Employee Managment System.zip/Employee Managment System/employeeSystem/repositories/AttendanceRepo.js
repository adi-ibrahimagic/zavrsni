import Attendance from '../models/Attendance.js'; // Assuming you have defined the model

class AttendanceRepository {
   async addAttendance(employeeId, date, status) {
        try {
            const attendance = await Attendance.create({
                employee_id: employeeId,
                date: date,
                status: status
            });

            return attendance;
        } catch (error) {
            console.error(error);
            throw error;
        }
    }
    async findByEmployeeId(employeeId) {
        return await Attendance.findAll({
            where: {
                employee_id: employeeId
            }
        });
    }

    async findAll() {
        return await Attendance.findAll();
    }

    async getById(id) {
        return await Attendance.findByPk(id);
    }

    async deleteById(id) {
        const attendance = await Attendance.findByPk(id);
        if (attendance) {
            await attendance.destroy();
        }
    }

    async create(attendanceData) {
        return await Attendance.create(attendanceData);
    }

    async updateAttendanceStatusByEmployeeId(employeeId, newStatus) {
    try {
      const attendance = await Attendance.findOne({
        where: { employee_id: employeeId },
      });

      if (attendance) {
        await attendance.update({ status: newStatus });
        return attendance; // Return the updated attendance object if needed
      } else {
        return null; // Return null if attendance with the given employee ID is not found
      }
    } catch (error) {
      throw error;
    }
  }
  async updateAttendanceTimeOut(employeeId, newTimeOut) {
    try {
      const attendance = await Attendance.findOne({
        where: { employee_id: employeeId },
        order: [['id', 'DESC']],
      });
        console.log("Attendance before update:", attendance);

      if (attendance) {
        await attendance.update({ time_out: newTimeOut });
        return attendance; // Return the updated attendance object if needed
      } else {
        return null; // Return null if attendance with the given employee ID is not found
      }
    } catch (error) {
      throw error;
    }
  }
  
}

export default new AttendanceRepository();
