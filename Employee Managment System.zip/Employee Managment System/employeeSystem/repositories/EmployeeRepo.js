import { Op } from 'sequelize';
import Employee from '../models/Employee.js';
import EmployeePasswords from '../models/EmployeePasswords.js';

class EmployeeRepo {
    async findByDepartmentId(departmentId) {
        return await Employee.findAll({
            where: { department_id: departmentId }
        });
    }

    async findByPk(id) {
        try {
            const employee = await Employee.findByPk(id);
            return employee;
        } catch (error) {
            throw error;
        }
    }

    async findByEmail(email) {
        return await Employee.findOne({
            where: { email: email }
        });
    }

    async findByName(name) {
        return await Employee.findAll({
            where: { name: name }
        });
    }

    async checkPassword(employeeId, password) {
        const employeePassword = await EmployeePasswords.findOne({
            where: {
                employee_id: employeeId,
                password: password
            }
        });
        return !!employeePassword;
    }

    async updateEmployee(id, employeeData) {
        const [updatedRowsCount, updatedEmployees] = await Employee.update(employeeData, {
            where: { id: id },
            returning: true
        });

        if (updatedRowsCount === 0) {
            throw new Error('Employee not found');
        }

        return updatedEmployees[0];
    }

    async createEmployee(employeeData) {
        try {
            const newEmployee = await Employee.create(employeeData);
            return newEmployee;
        } catch (error) {
            throw error;
        }
    }

     async getAllEmployees() {
        try {
            const employees = await Employee.findAll();
            return employees;
        } catch (error) {
            throw error;
        }
    }

     async deleteById(id) {
        const employee = await Employee.findOne({ where: { id } });
        await employee.destroy();
        return employee;
    }
}

export default new EmployeeRepo();
