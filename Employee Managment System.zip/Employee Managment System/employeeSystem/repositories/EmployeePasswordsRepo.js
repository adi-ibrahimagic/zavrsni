import EmployeePasswords from '../models/EmployeePasswords.js';
import db from '../config/dbConfig.js'; 


class EmployeePasswordsRepo {
    async checkPassword(employee_id, password) {
        try {
            const employeePassword = await EmployeePasswords.findOne({
                where: {
                    employee_id: employee_id, // Use the correct column name here
                    password: password
                }
            });

            return !!employeePassword; // Return true if employeePassword is found
        } catch (error) {
            console.error(error);
            throw error;
        }
    }
     async savePassword(employeeId, password) {
        const query = 'INSERT INTO employee_passwords (employee_id, password) VALUES (:employeeId, :password)';
        try {
            const result = await db.query(query, {
                replacements: { employeeId, password },
                type: db.QueryTypes.INSERT
            });
            return result;
        } catch (error) {
            throw error;
        }
    }
     async deletePassword(employee_id) {
        const query = 'DELETE FROM employee_passwords WHERE employee_id = :employee_id';
        try {
            const result = await db.query(query, {
                replacements: { employee_id },
                type: db.QueryTypes.DELETE
            });
            return result;
        } catch (error) {
            throw error;
        }
    }
}



export default new EmployeePasswordsRepo();
