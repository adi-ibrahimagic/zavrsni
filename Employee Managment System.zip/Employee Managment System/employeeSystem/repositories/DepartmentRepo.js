import Department from '../models/Department.js'; // Assuming you have defined the model

class DepartmentRepository {
    async findAll() {
        return await Department.findAll();
    }

    async findById(id) {
        return await Department.findByPk(id);
    }

    async createDepartment(departmentData) {
        return await Department.create(departmentData);
    }

    async update(id, departmentData) {
        const department = await Department.findByPk(id);
        if (department) {
            await department.update(departmentData);
        }
    }

    async deleteById(id) {
        const department = await Department.findByPk(id);
        if (department) {
            await department.destroy();
        }
    }
    
}

export default new DepartmentRepository();
