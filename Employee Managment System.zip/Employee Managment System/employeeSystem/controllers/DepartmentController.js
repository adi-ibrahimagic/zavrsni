import Department from '../models/Department.js'; // Import your Department model
import DepartmentRepository from '../repositories/DepartmentRepo.js'; // Import your DepartmentRepository

class DepartmentController {
    async getAllDepartments(req, res) {
        try {
            const departments = await DepartmentRepository.findAll(); // Use findAll() to get all departments
            res.json(departments);
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

    async getDepartmentById(req, res) {
        const { id } = req.params;
        try {
            const department = await DepartmentRepository.findById(id);
            if (department) {
                res.json(department);
            } else {
                res.status(404).json({ message: 'Department not found' });
            }
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

    async createDepartment(req, res) {
        try {
            // Extract department data from the request body
            const { name, description, manager } = req.body;

            // Create a new department record
            const newDepartment = await DepartmentRepository.createDepartment({
                name,
                description,
                manager
            });

            res.status(201).json({ message: 'Department created successfully', department: newDepartment });
        } catch (error) {
            res.status(500).json({ message: 'Error creating department', error: error.message });
        }
    }

    async updateDepartment(req, res) {
        
            const departmentId = req.params.id; // Extract department ID from the request parameter
            const updatedDepartmentData = req.body; // New data to update the department
           
            // Update the department data
            const updatedDepartment = await DepartmentRepository.update(departmentId, updatedDepartmentData);

            if (!updatedDepartment) {
                return res.status(404).json({ message: 'Department not found' });
            }

            res.json({ message: 'Department updated successfully', department: updatedDepartment });
        
    }

    async deleteDepartment(req, res) {
    try {
        const departmentId = req.params.id;
        DepartmentRepository.deleteById(departmentId);

        res.json({ message: 'Department deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error deleting department', error: error.message });
    }
}
}

export default new DepartmentController();
