import EmployeeRepo from '../repositories/EmployeeRepo.js';
import EmployeePasswordsRepo from '../repositories/EmployeePasswordsRepo.js';

class EmployeeController {
   async getAllEmployees(req, res) {
        try {
            const employees = await EmployeeRepo.getAllEmployees();
            res.json(employees);
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

    async searchEmployeeByName(req, res) {
        try {
            const { name } = req.body;

            if (!name) {
                return res.status(400).json({ message: 'Name is required' });
            }

            const searchResults = await EmployeeRepo.findByName(name);

            if (searchResults.length === 0) {
                return res.status(404).json({ message: 'No employees found' });
            }

            res.json(searchResults);
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

    async getEmployeeById(req, res) {
        const { id } = req.params;
        try {
            const employee = await EmployeeRepo.findByPk(id);
            if (employee) {
                res.json(employee);
            } else {
                res.status(404).json({ message: 'Employee not found' });
            }
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

    // Implement other controller methods here

    async loginEmployee(req, res) {
        const { email, password } = req.body;
        try {
            const employee = await EmployeeRepo.findByEmail(email);
            if (employee && await EmployeePasswordsRepo.checkPassword(employee.id, password)) {
                res.status(200).json({ message: 'Login successful' });
            } else {
                res.status(401).json({ message: 'Invalid email or password' });
            }
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

    async getEmployeesByDepartment(req, res) {
        const { departmentId } = req.params;
        try {
            const employees = await EmployeeRepo.findByDepartmentId(parseInt(departmentId));
            res.json(employees);
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }
    
    async updateEmployee(req, res) {
        const { id } = req.params;
        const updatedEmployeeData = req.body;

        try {
            const existingEmployee = await EmployeeRepo.findByPk(id);

            if (!existingEmployee) {
                return res.status(404).json({ message: 'Employee not found' });
            }

            if (updatedEmployeeData.name) {
                existingEmployee.name = updatedEmployeeData.name;
            }
            if (updatedEmployeeData.jobTitle) {
                existingEmployee.job_title = updatedEmployeeData.jobTitle;
            }
            if (updatedEmployeeData.departmentId) {
                existingEmployee.department_id = updatedEmployeeData.departmentId;
            }
           if (updatedEmployeeData.email != null) {
            existingEmployee.email = updatedEmployeeData.email;
        }
        if (updatedEmployeeData.phoneNumber != null) {
            existingEmployee.phone_number = updatedEmployeeData.phoneNumber;
        }
        if (updatedEmployeeData.hireDate != null) {
            existingEmployee.hire_date = updatedEmployeeData.hireDate;
        }
        if (updatedEmployeeData.salary != null) {
            existingEmployee.salary = updatedEmployeeData.salary;
        }
        if (updatedEmployeeData.admin != null) {
            existingEmployee.admin = updatedEmployeeData.admin;
        }

            await existingEmployee.save();

            res.json({ message: 'Employee updated successfully', employee: existingEmployee });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

    async registerEmployee(req, res) {
        try {
            const { employee, password } = req.body;
            console.log(req);
            const existingEmployee = await EmployeeRepo.findByEmail(employee.email);
            if (existingEmployee) {
                return res.status(400).json({ message: 'Email already exists' });
            }

            const newEmployee = await EmployeeRepo.createEmployee(employee);
            await EmployeePasswordsRepo.savePassword(newEmployee.id, password);

            res.status(201).json({ message: 'Registration successful' });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }
    
    async deleteEmployee(req, res) {
    try {
        
        const employeeId = req.params.id; // Extract employee ID from the request parameter
    
        // Delete employee's password first
        await EmployeePasswordsRepo.deletePassword(employeeId);

        // Delete the employee
        const deletedRowsCount = await EmployeeRepo.deleteById(employeeId);

        if (deletedRowsCount === 0) {
            return res.status(404).json({ message: 'Employee not found' });
        }

        res.json({ message: 'Employee deleted successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error deleting employee', error: error.message });
    }
}

async searchEmployeeByEmail(req, res) {
        try {
            const { email } = req.body;

            if (!email) {
                return res.status(400).json({ message: 'Email is required' });
            }

            const employee = await EmployeeRepo.findByEmail(email);

            if (!employee) {
                return res.status(404).json({ message: 'Employee not found' });
            }

            res.json(employee);
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

}

export default new EmployeeController();
