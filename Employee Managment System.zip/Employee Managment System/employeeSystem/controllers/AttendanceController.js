import Attendance from '../models/Attendance.js'; 
import AttendanceRepository from '../repositories/AttendanceRepo.js'; 

class AttendanceController {
    async getAllAttendance(req, res) {
        try {
            const attendanceList = await Attendance.findAll(); 
            res.json(attendanceList);
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

    async getAttendanceById(req, res) {
        const { id } = req.params;
        try {
            const attendance = await AttendanceRepository.findById(id);
            if (attendance) {
                res.json(attendance);
            } else {
                res.status(404).json({ message: 'Attendance record not found' });
            }
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

    async deleteAttendance(req, res) {
        const { id } = req.params;
        try {
            const deletedAttendance = await AttendanceRepository.deleteAttendance(id);
            if (!deletedAttendance) {
                res.status(404).json({ message: 'Attendance record not found' });
            } else {
                res.json({ message: 'Attendance record deleted successfully' });
            }
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }


async addAttendance(req, res) {
    try {
        const { employee_id, date, time_in, time_out, status } = req.body;

        // Create a new attendance record
        const attendance = await Attendance.create({
            employee_id: employee_id,
            date: date,
            time_in: time_in,
            time_out: time_out,
            status: status
        });

        res.status(200).json({ message: 'Attendance added successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}

    async getAttendanceByEmployeeId(req, res) {
        const { employee_id } = req.params;
        try {
            const attendanceList = await AttendanceRepository.findByEmployeeId(employee_id);
            res.json(attendanceList);
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

     async updateAttendanceStatus(req, res) {
        console.log(req.body); // Add this line to check the request body

        const { employeeId } = req.params;
        const { newStatus } = req.body;

        try {
            const attendanceList = await AttendanceRepository.findByEmployeeId(employeeId);

            if (attendanceList.length === 0) {
                return res.status(404).json({ message: 'No attendance records found' });
            }

            for (const attendance of attendanceList) {
                await attendance.update({ status: newStatus });
            }

            res.json({ message: 'Status updated successfully' });
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

    async updateAttendanceTimeOut(req, res) {
        const { employeeId } = req.params;
        try {
        const currentTime = new Date().toLocaleTimeString('en-US', { hour12: false }); // Get current time in HH:MM:SS format
            const updatedAttendance = await AttendanceRepository.updateAttendanceTimeOut(employeeId, currentTime);
        
            if (updatedAttendance) {
                res.json({ message: 'Attendance time out updated successfully' });
            } else {
                res.status(404).json({ message: 'No attendance records found for the employee' });
            }
        } catch (error) {
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }
     
}

export default new AttendanceController();
