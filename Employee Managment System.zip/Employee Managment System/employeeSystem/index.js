import express from 'express';
import cors from 'cors';
import sequelize from './config/dbConfig.js';
import departmentRoutes from './routes/DepartmentRoutes.js';
import attendanceRoutes from './routes/AttendanceRoutes.js';
import employeeRoutes from './routes/EmployeeRoutes.js';



const app = express();
const PORT = 8080;

app.use(cors());
app.use(express.json());

app.use('/employee', employeeRoutes);
app.use('/department', departmentRoutes);
app.use('/attendance', attendanceRoutes);


sequelize.sync()
  .then(() => {
    console.log('Database synced');
    
    // Start the server only after the database is synced
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
    });
  })
  .catch(err => {
    console.error('Error syncing database:', err);
  });
