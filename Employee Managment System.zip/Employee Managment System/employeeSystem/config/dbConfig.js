import { Sequelize } from 'sequelize';

const sequelize = new Sequelize('employee', 'root', 'root', {
    host: 'localhost',
    dialect: 'mysql',
    port: 3306,
    dialectOptions: {
        // Additional options here if needed
    }
});

export default sequelize;
