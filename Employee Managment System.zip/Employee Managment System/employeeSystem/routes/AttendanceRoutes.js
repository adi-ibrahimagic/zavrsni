import express from 'express';
import AttendanceController from '../controllers/AttendanceController.js';

const router = express.Router();

router.get('/getAll', AttendanceController.getAllAttendance);
router.get('/getById/:id', AttendanceController.getAttendanceById);
router.delete('/deleteAttendance/:id', AttendanceController.deleteAttendance);
router.post('/addAttendance', AttendanceController.addAttendance);
router.get('/getByEmployeeId/:employee_id', AttendanceController.getAttendanceByEmployeeId);
router.put('/updateStatus/:employeeId', AttendanceController.updateAttendanceStatus);
router.put('/updateTimeOut/:employeeId', AttendanceController.updateAttendanceTimeOut);

export default router;
