import express from 'express';
import EmployeeController from '../controllers/EmployeeController.js';

const router = express.Router();

router.get('/getEmployees', EmployeeController.getAllEmployees);
router.get('/getEmployee/:id', EmployeeController.getEmployeeById);
router.delete('/deleteEmployee/:id', EmployeeController.deleteEmployee);
router.post('/login', EmployeeController.loginEmployee);
router.post('/register', EmployeeController.registerEmployee);
router.post('/searchEmail', EmployeeController.searchEmployeeByEmail);
router.get('/getEmployeesByDepartment/:departmentId', EmployeeController.getEmployeesByDepartment);
router.put('/updateEmployee/:id', EmployeeController.updateEmployee);
router.post('/search', EmployeeController.searchEmployeeByName);

export default router;
