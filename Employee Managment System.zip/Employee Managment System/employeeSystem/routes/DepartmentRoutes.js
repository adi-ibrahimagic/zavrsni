import express from 'express';
import DepartmentController from '../controllers/DepartmentController.js';

const router = express.Router();

router.get('/getAll', DepartmentController.getAllDepartments);
router.get('/getById/:id', DepartmentController.getDepartmentById);
router.post('/create', DepartmentController.createDepartment);
router.put('/updateDepartment/:id', DepartmentController.updateDepartment);
router.delete('/deleteDepartment/:id', DepartmentController.deleteDepartment);

export default router;
