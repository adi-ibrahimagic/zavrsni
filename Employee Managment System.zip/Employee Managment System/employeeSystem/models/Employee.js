import { DataTypes } from 'sequelize';
import sequelize from '../config/dbConfig.js';

const Employee = sequelize.define('Employee', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    job_title: {
        type: DataTypes.STRING
    },
    department_id: {
        type: DataTypes.INTEGER
    },
    email: {
        type: DataTypes.STRING
    },
    phone_number: {
        type: DataTypes.STRING
    },
    hire_date: {
        type: DataTypes.STRING
    },
    salary: {
        type: DataTypes.DOUBLE
    },
    admin: {
        type: DataTypes.BOOLEAN
    }
}, {
    table_name: 'Employees',
    timestamps: false
});

export default Employee;
