import { DataTypes } from 'sequelize';
import sequelize from '../config/dbConfig.js';

const EmployeePasswords = sequelize.define('EmployeePasswords', {
    employee_id: {
        type: DataTypes.INTEGER,
        primaryKey: true
    },
    password: {
        type: DataTypes.STRING
    }
}, {
    tableName: 'employee_passwords',
    timestamps: false // Assuming the table doesn't have timestamp columns
});

export default EmployeePasswords;
