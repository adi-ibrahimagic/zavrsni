import { DataTypes } from 'sequelize';
import sequelize from '../config/dbConfig.js';
import Employee from './Employee.js'; 

const Attendance = sequelize.define('Attendance', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    employee_id: {
        type: DataTypes.INTEGER
    },
    date: {
        type: DataTypes.DATEONLY
    },
    time_in: {
        type: DataTypes.TIME
    },
    time_out: {
        type: DataTypes.TIME
    },
    status: {
        type: DataTypes.STRING
    }
}, {
    tableName: 'Attendance',
    timestamps: false // Disable timestamps
});

Attendance.belongsTo(Employee, {
    foreignKey: 'employee_id'
});

export default Attendance;
