class EmployeeRegistrationRequest {
    constructor(employee, password) {
        this.employee = employee;
        this.password = password;
    }

    getEmployee() {
        return this.employee;
    }

    setEmployee(employee) {
        this.employee = employee;
    }

    getPassword() {
        return this.password;
    }

    setPassword(password) {
        this.password = password;
    }
}

export default EmployeeRegistrationRequest;
