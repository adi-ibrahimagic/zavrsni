import { DataTypes } from 'sequelize';
import sequelize from '../config/dbConfig.js'; 

const Department = sequelize.define('Department', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING
    },
    description: {
        type: DataTypes.STRING
    },
    manager: {
        type: DataTypes.STRING
    }
}, {
    tableName: 'Departments',
    timestamps: false 
});

export default Department;
