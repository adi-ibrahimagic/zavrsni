-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: employee
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` int NOT NULL,
  `date` date NOT NULL,
  `time_in` time NOT NULL,
  `time_out` time DEFAULT NULL,
  `status` varchar(255) DEFAULT 'green',
  PRIMARY KEY (`id`),
  KEY `employee_id` (`employee_id`),
  CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendance`
--

LOCK TABLES `attendance` WRITE;
/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` VALUES (77,42,'2022-01-15','09:00:00','17:00:00','red'),(78,43,'2022-02-20','08:30:00','16:30:00','green'),(79,44,'2022-03-25','09:15:00','17:15:00','green'),(80,45,'2022-04-10','09:30:00','17:30:00','green'),(81,42,'2023-09-11','18:43:45','00:00:00','red'),(82,42,'2023-09-11','18:50:07','20:52:35','red'),(83,42,'2023-09-11','18:53:05','20:55:22','red'),(84,42,'2023-09-11','22:56:13','00:00:00','red'),(85,42,'2023-09-11','23:03:49','01:04:21','red'),(86,42,'2023-09-11','23:04:36','01:08:03','red'),(87,49,'2023-09-11','23:08:22','01:09:09','green'),(88,42,'2023-09-11','23:09:21','01:14:59','red'),(89,42,'2023-09-11','23:15:07','01:23:56','red'),(90,49,'2023-09-11','23:24:16','01:32:46','green'),(91,49,'2023-09-11','23:33:07','01:34:06','green'),(92,44,'2023-09-11','23:34:28','01:34:48','green'),(93,42,'2023-09-11','23:35:09','01:43:08','red'),(94,42,'2023-09-11','23:44:14','01:46:22','red'),(95,42,'2023-09-11','23:48:03','01:51:54','red'),(96,42,'2023-09-11','23:52:27','01:55:30','red'),(97,49,'2023-09-11','23:55:51','01:57:20','green'),(98,42,'2023-09-11','23:57:28','01:57:50','red'),(99,49,'2023-09-11','23:58:04','01:58:47','green'),(100,42,'2023-09-11','23:59:03','02:01:35','red'),(101,49,'2023-09-12','00:01:48','02:04:17','green'),(102,42,'2023-09-12','00:04:24','02:05:33','red'),(103,42,'2023-09-12','23:28:58','01:29:01','red'),(104,49,'2023-09-12','23:29:13','01:34:12','green'),(105,42,'2023-09-12','23:35:51','01:54:44','red'),(106,49,'2023-09-12','23:54:54','01:56:40','green'),(107,42,'2023-09-12','23:57:27','02:02:12','red'),(108,44,'2023-09-13','00:02:35','02:02:57','green'),(109,42,'2023-09-13','00:03:03','02:12:36','red'),(110,42,'2023-09-13','00:13:10','02:13:25','green'),(111,42,'2023-09-13','00:14:46','02:15:40','green'),(112,54,'2023-09-13','00:15:49','02:16:04','red'),(113,42,'2023-09-13','00:16:10','00:00:00','green'),(114,42,'2023-09-13','19:45:56','22:13:50','green'),(115,49,'2023-09-13','20:14:04','22:14:18','green'),(116,49,'2023-09-13','20:14:28','22:15:37','green'),(117,42,'2023-09-13','20:15:43','00:00:00','green');
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-13 22:19:09
